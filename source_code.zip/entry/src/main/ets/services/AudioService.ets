import { media } from '@kit.MediaKit';
import { audio } from '@kit.AudioKit';
import { common } from '@kit.AbilityKit';
import { fileIo as fs } from '@kit.CoreFileKit';


export enum AudioStatus {
  Undefined,
  Playing,
  Paused,
  Released,
}

@ObservedV2
export class AudioService {
  static _instance: AudioService;

  // Ensure only one instance of this ViewModel is created
  static getInstance() {
    if (!AudioService._instance) {
      AudioService._instance = new AudioService(AudioStatus.Undefined);
      AudioService._instance.volume = 0.5
    }
    return AudioService._instance;
  }

  constructor(audioStatus: AudioStatus) {
    this.audioStatus = audioStatus;
  }


  private player: media.AVPlayer | undefined;
  @Trace audioStatus: AudioStatus;
  private progressTimer: number | undefined;
  @Trace progress: number = 0;
  @Trace volume: number = 0;
  @Trace canPlay: boolean = false;

  private startProgressUpdater() {
    this.clearProgressUpdater(); // Clear any existing timer
    this.progressTimer = setInterval(() => {
      this.progress = this.getCurrentProgressPercentage();
      console.info(`Progress: ${this.progress}%`);
      // You can also notify the UI here via state or event if needed
    }, 1000); // update every second
  }

  private clearProgressUpdater() {
    if (this.progressTimer !== undefined) {
      clearInterval(this.progressTimer);
      this.progressTimer = undefined;
    }
  }


  public getCurrentProgressPercentage(): number {
    if (!this.player || this.player.duration === 0) {
      return 0;
    }

    const currentSeconds = this.player.currentTime / 1_000_000;
    const totalSeconds = this.player.duration / 1_000_000;

    return Math.floor((currentSeconds / totalSeconds) * 100);
  }

  setCallbacks(avPlayer: media.AVPlayer) {
    avPlayer.on('stateChange', async (state: string) => {
      console.info('AVPlayer state:', state);
      switch (state) {
        case 'initialized':
          avPlayer.audioRendererInfo = {
            usage: audio.StreamUsage.STREAM_USAGE_MUSIC,
            rendererFlags: 0,
          };
          avPlayer.prepare();
          break;
        case 'prepared':
          this.audioStatus = AudioStatus.Playing
          avPlayer.play();
          this.startProgressUpdater();
          break;
        case 'completed':
          this.audioStatus = AudioStatus.Released
          this.progress = 100;
          this.canPlay = false;
          avPlayer.stop();
          this.clearProgressUpdater();
          break;
        case 'stopped':
          avPlayer.reset();
          this.clearProgressUpdater();
          break;
        case 'pause':
          avPlayer.pause();
          break;
      }
    });

    avPlayer.on('error', (err) => {
      console.error('AVPlayer error:', err.message);
      avPlayer.reset();
    });
  }

  async playAudioFromFile(filePath: string): Promise<void> {
    try {
      this.player = await media.createAVPlayer();
      this.setCallbacks(this.player);

      // open file to get fd, offset, length
      const file = await fs.open(filePath, fs.OpenMode.READ_ONLY);
      const stat = await fs.stat(filePath);

      const avFileDescriptor: media.AVFileDescriptor = {
        fd: file.fd,
        offset: 0,
        length: stat.size,
      };

      this.player.fdSrc = avFileDescriptor;
    } catch (err) {
      console.error('Error playing audio file:', err);
    }
  }

  public async playEmbeddedMp3(context: common.UIAbilityContext, fileName: string) {
    this.release();
    const resourceFd = await context.resourceManager.getRawFd(fileName);

    const avFileDescriptor: media.AVFileDescriptor = {
      fd: resourceFd.fd,
      offset: resourceFd.offset,
      length: resourceFd.length,
    };
    this.player = await media.createAVPlayer();
    this.setCallbacks(this.player);
    this.player.fdSrc = avFileDescriptor;
  }

  public pause() {
    this.audioStatus = AudioStatus.Paused
    this.player?.pause();
  }

  public resume() {
    this.audioStatus = AudioStatus.Playing
    this.player?.play();
  }

  public stop() {
    this.audioStatus = AudioStatus.Released
    this.player?.stop();
  }

  public release() {
    this.audioStatus = AudioStatus.Released
    this.player?.reset();
    this.clearProgressUpdater();
  }

  setVolume() {
    this.player?.setVolume(this.volume);
  }
}
